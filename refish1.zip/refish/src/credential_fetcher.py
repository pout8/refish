#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Refish 凭据获取器
浮浮酱精心重构的统一凭据管理系统 ฅ'ω'ฅ

特性:
- 统一的凭据获取接口
- 支持多平台扩展 (Kunpeng Lab, 其他云平台)
- 集成新的认证管理器
- 缓存和错误处理
- 配置外部化
"""

import os
import json
import sqlite3
import requests
import urllib3
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Protocol, Any
from pathlib import Path
from dataclasses import dataclass
from enum import Enum

# 导入我们的认证管理器
from auth_manager import AuthManager

# 禁用SSL警告
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)


class NetworkStatus(Enum):
    """网络状态枚举"""
    NORMAL = 0
    ABNORMAL = 1
    UNKNOWN = -1


@dataclass
class ServerInfo:
    """服务器信息数据类"""
    bmc_ip: str
    server_id: Optional[str] = None
    group_id: Optional[str] = None
    network_status: NetworkStatus = NetworkStatus.UNKNOWN
    hostname: Optional[str] = None
    location: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        """转换为字典格式"""
        return {
            'bmc_ip': self.bmc_ip,
            'server_id': self.server_id,
            'group_id': self.group_id,
            'network_status': self.network_status.value,
            'hostname': self.hostname,
            'location': self.location
        }


@dataclass
class BMCCredentials:
    """BMC凭据数据类"""
    ip: str
    username: str
    password: str
    expires_at: Optional[datetime] = None
    last_updated: Optional[datetime] = None

    def is_expired(self) -> bool:
        """检查凭据是否过期"""
        if not self.expires_at:
            return False
        return datetime.now() > self.expires_at

    def to_dict(self) -> Dict[str, Any]:
        """转换为字典格式"""
        return {
            'ip': self.ip,
            'username': self.username,
            'password': self.password,
            'expires_at': self.expires_at.isoformat() if self.expires_at else None,
            'last_updated': self.last_updated.isoformat() if self.last_updated else None
        }


class CredentialProvider(Protocol):
    """凭据提供器接口 - 遵循开放/封闭原则"""

    def fetch_servers(self, ip_list: List[str]) -> List[ServerInfo]:
        """获取服务器信息列表"""
        ...

    def fetch_credentials(self, server_info: ServerInfo) -> Optional[BMCCredentials]:
        """获取服务器的BMC凭据"""
        ...


class KunpengLabProvider:
    """Kunpeng Lab 凭据提供器"""

    def __init__(self, config: Optional[Dict[str, Any]] = None):
        self.config = config or {}
        self.base_url = self.config.get(
            'base_url',
            'https://kunpeng-lab.server.huawei.com'
        )
        self.group_id = self.config.get(
            'group_id',
            'paddde0df492d4f9487ac491ad2f4c501'
        )
        self.timeout = self.config.get('timeout', 30)

    def _prepare_session(self) -> requests.Session:
        """准备并认证会话，优先使用缓存"""
        auth_manager = AuthManager()
        session = None

        try:
            # 1. 从环境获取凭据以拿到用户名
            credentials = auth_manager._get_credentials_from_env('huawei_w3')
            username = credentials.get('username')

            # 2. 尝试从缓存获取会话
            if username:
                session = auth_manager.get_cached_session('huawei_w3', username)

            if session:
                print("✅ 使用缓存的 huawei_w3 会话")
            else:
                # 3. 如果缓存无效或不存在，执行新认证
                print("ℹ️ 无有效缓存会话，执行新认证...")
                session = auth_manager.authenticate('huawei_w3')

        except (ValueError, RuntimeError) as e:
            print(f"❌ 认证准备失败: {e}")
            # 如果认证失败，创建一个基础 session 以免后续代码失败
            session = requests.Session()

        # 4. 为会话配置 Kunpeng Lab 特定设置
        session.headers.update({
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36",
            "Origin": "https://computing.lab.rnd.huawei.com",
            "Referer": "https://computing.lab.rnd.huawei.com/",
            "groupId": self.group_id
        })

        # 5. 初始化Kunpeng Lab应用级会话
        self._initialize_kunpeng_session(session)

        return session

    def _initialize_kunpeng_session(self, session: requests.Session) -> bool:
        """初始化Kunpeng Lab应用级会话"""
        url = f"{self.base_url}/v1/system/user/login"
        try:
            response = session.post(url, verify=False, timeout=15)
            response.raise_for_status()
            print("✅ Kunpeng Lab 会话初始化成功")
            return True
        except requests.exceptions.RequestException as e:
            print(f"❌ Kunpeng Lab 会话初始化失败: {e}")
            return False

    def fetch_servers(self, ip_list: List[str]) -> List[ServerInfo]:
        """从Kunpeng Lab获取服务器信息"""
        if not ip_list:
            return []

        session = self._prepare_session()
        url = f"{self.base_url}/v1/resource/server/get-server"

        end_date = datetime.now()
        start_date = end_date - timedelta(days=7)

        payload = {
            "data": {"bmc_ip": ip_list},
            "data_range": 1,
            "start_date": start_date.strftime('%Y-%m-%d'),
            "end_date": end_date.strftime('%Y-%m-%d'),
            "limit": len(ip_list) + 10,
            "offset": 1
        }

        try:
            print(f"🔍 正在查询 {len(ip_list)} 个服务器信息...")
            response = session.post(url, json=payload, verify=False, timeout=self.timeout)
            response.raise_for_status()

            data = response.json()
            if data.get('status_code') != 200:
                print(f"⚠️ API返回异常状态: {data.get('status_code')} - {data.get('msg')}")
                return []

            raw_servers = data.get('data', {}).get('res', [])
            servers = []

            for server_data in raw_servers:
                # 解析网络状态
                net_status = server_data.get('net_status', {})
                network_status = NetworkStatus.NORMAL if net_status.get('id') == 0 else NetworkStatus.ABNORMAL

                server_info = ServerInfo(
                    bmc_ip=server_data.get('bmc_ip', ''),
                    server_id=server_data.get('id'),
                    group_id=server_data.get('group_id'),
                    network_status=network_status,
                    hostname=server_data.get('hostname'),
                    location=server_data.get('location')
                )

                servers.append(server_info)

                if network_status == NetworkStatus.NORMAL:
                    print(f"✅ {server_info.bmc_ip} - 网络状态正常")
                else:
                    print(f"⚠️ {server_info.bmc_ip} - 网络状态异常: {net_status.get('name', '未知')}")

            return servers

        except requests.exceptions.RequestException as e:
            print(f"❌ 服务器信息查询失败: {e}")
            return []
        except json.JSONDecodeError as e:
            print(f"❌ 响应数据解析失败: {e}")
            return []

    def fetch_credentials(self, server_info: ServerInfo) -> Optional[BMCCredentials]:
        """获取指定服务器的BMC凭据"""
        if not server_info.server_id or not server_info.group_id:
            print(f"⚠️ {server_info.bmc_ip} - 缺少服务器ID或组ID")
            return None

        if server_info.network_status != NetworkStatus.NORMAL:
            print(f"⚠️ {server_info.bmc_ip} - 网络状态异常，跳过凭据获取")
            return None

        session = self._prepare_session()
        url = f"{self.base_url}/v1/resource/server/get-password"

        payload = {
            "id": server_info.server_id,
            "group_id": server_info.group_id,
            "password_type": "bmc",
            "resource_type": 0
        }

        try:
            response = session.post(url, json=payload, verify=False, timeout=15)
            response.raise_for_status()

            data = response.json()
            password_data = data.get('data', {}).get('res')

            if not password_data:
                print(f"❌ {server_info.bmc_ip} - 未获取到密码数据")
                return None

            # 假设返回的是字符串密码，实际API可能有不同结构
            password = password_data if isinstance(password_data, str) else str(password_data)

            # 默认用户名通常是 root 或 admin
            username = "root"  # 可以从配置中获取

            credentials = BMCCredentials(
                ip=server_info.bmc_ip,
                username=username,
                password=password,
                expires_at=datetime.now() + timedelta(hours=24),  # 24小时过期
                last_updated=datetime.now()
            )

            print(f"✅ {server_info.bmc_ip} - 凭据获取成功")
            return credentials

        except requests.exceptions.RequestException as e:
            print(f"❌ {server_info.bmc_ip} - 凭据获取失败: {e}")
            return None
        except Exception as e:
            print(f"❌ {server_info.bmc_ip} - 处理凭据时出错: {e}")
            return None


class CredentialFetcher:
    """
    统一凭据获取器
    遵循单一职责原则 - 专注于凭据获取和管理
    """

    def __init__(self, db_path: str = "refish_hardware.db"):
        self.db_path = Path(db_path)
        self.providers: Dict[str, CredentialProvider] = {}

        # 注册凭据提供器
        self._register_providers()

        # 确保数据库表存在
        self._ensure_credentials_table()

    def _register_providers(self):
        """注册凭据提供器 - 遵循依赖倒置原则"""
        self.providers['kunpeng_lab'] = KunpengLabProvider()

    def _ensure_credentials_table(self):
        """确保凭据表存在"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()

                # 检查servers表是否存在
                cursor.execute("""
                    SELECT name FROM sqlite_master
                    WHERE type='table' AND name='servers'
                """)

                if not cursor.fetchone():
                    cursor.execute("""
                        CREATE TABLE servers (
                            id INTEGER PRIMARY KEY AUTOINCREMENT,
                            bmc_ip TEXT UNIQUE NOT NULL,
                            username TEXT NOT NULL,
                            password TEXT NOT NULL,
                            status TEXT DEFAULT 'unknown',
                            hostname TEXT,
                            location TEXT,
                            network_status INTEGER DEFAULT -1,
                            expires_at TIMESTAMP,
                            last_updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                            provider TEXT DEFAULT 'kunpeng_lab'
                        )
                    """)
                    print("✅ 服务器凭据表创建成功")

        except sqlite3.Error as e:
            print(f"❌ 数据库操作失败: {e}")

    def fetch_from_file(self, ip_file: str = "bmc_ip.txt", provider: str = "kunpeng_lab") -> List[BMCCredentials]:
        """从IP文件获取凭据"""
        ip_list = self._read_ips_from_file(ip_file)
        if not ip_list:
            print(f"⚠️ IP文件 {ip_file} 为空或不存在")
            return []

        return self.fetch_credentials(ip_list, provider)

    def fetch_credentials(self, ip_list: List[str], provider: str = "kunpeng_lab") -> List[BMCCredentials]:
        """
        批量获取BMC凭据, 优先从缓存加载

        Args:
            ip_list: IP地址列表
            provider: 凭据提供器名称

        Returns:
            BMC凭据列表
        """
        if provider not in self.providers:
            raise ValueError(f"不支持的凭据提供器: {provider}")

        # 1. 从缓存中获取凭据
        cached_credentials = self.get_cached_credentials(ip_list)
        cached_ips = {cred.ip for cred in cached_credentials}
        
        # 2. 识别需要远程获取的IP
        pending_ips = [ip for ip in ip_list if ip not in cached_ips]

        # 3. 如果所有凭据都在缓存中，直接返回
        if not pending_ips:
            print("✅ 所有凭据均从缓存加载")
            return cached_credentials

        print(f"💿 从缓存加载了 {len(cached_credentials)} 个凭据。")
        print(f"📡 准备从远程为 {len(pending_ips)} 个IP获取新凭据...")

        # 4. 为待处理的IP获取新凭据
        credential_provider = self.providers[provider]
        
        # 获取服务器信息
        servers = credential_provider.fetch_servers(pending_ips)
        if not servers:
            print("❌ 未为待处理的IP找到任何服务器信息")
            return cached_credentials

        # 获取凭据
        new_credentials = []
        print(f"🔑 开始获取 {len(servers)} 个服务器的新凭据...")
        for server in servers:
            credential = credential_provider.fetch_credentials(server)
            if credential:
                new_credentials.append(credential)
                # 保存到数据库
                self._save_credential_to_db(credential, server)

        # 5. 合并缓存和新获取的凭据
        all_credentials = cached_credentials + new_credentials

        # 6. 报告未找到的IP
        found_ips = {cred.ip for cred in all_credentials}
        unfound_ips = set(ip_list) - found_ips

        if unfound_ips:
            print(f"\n⚠️ 未找到以下IP的凭据:")
            for ip in unfound_ips:
                print(f"   - {ip}")

        print(f"\n✅ 成功获取 {len(all_credentials)} 个服务器的凭据")
        return all_credentials

    def _read_ips_from_file(self, filename: str) -> List[str]:
        """从文件读取IP地址列表"""
        try:
            ip_path = Path(filename)
            if not ip_path.exists():
                return []

            lines = ip_path.read_text(encoding='utf-8').splitlines()
            ip_list = [line.strip() for line in lines if line.strip()]
            print(f"📋 从 {filename} 读取到 {len(ip_list)} 个IP地址")
            return ip_list

        except Exception as e:
            print(f"❌ 读取IP文件失败: {e}")
            return []

    def _save_credential_to_db(self, credential: BMCCredentials, server: ServerInfo):
        """保存凭据到数据库"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                cursor.execute("""
                    INSERT OR REPLACE INTO servers
                    (bmc_ip, username, password, hostname, location, network_status,
                     expires_at, last_updated, provider, status)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """, (
                    credential.ip, credential.username, credential.password,
                    server.hostname, server.location, server.network_status.value,
                    credential.expires_at, credential.last_updated,
                    'kunpeng_lab', 'active'
                ))

                print(f"💾 {credential.ip} 凭据已保存到数据库")

        except sqlite3.Error as e:
            print(f"⚠️ 保存凭据失败: {e}")

    def get_cached_credentials(self, ip_list: List[str]) -> List[BMCCredentials]:
        """从数据库获取缓存的凭据"""
        if not ip_list:
            return []

        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                placeholders = ','.join(['?' for _ in ip_list])
                cursor.execute(f"""
                    SELECT bmc_ip, username, password, expires_at, last_updated
                    FROM servers
                    WHERE bmc_ip IN ({placeholders}) AND status = 'active'
                """, ip_list)

                credentials = []
                for row in cursor.fetchall():
                    bmc_ip, username, password, expires_at_str, last_updated_str = row

                    expires_at = datetime.fromisoformat(expires_at_str) if expires_at_str else None
                    last_updated = datetime.fromisoformat(last_updated_str) if last_updated_str else None

                    credential = BMCCredentials(
                        ip=bmc_ip,
                        username=username,
                        password=password,
                        expires_at=expires_at,
                        last_updated=last_updated
                    )

                    # 检查是否过期
                    if not credential.is_expired():
                        credentials.append(credential)

                if credentials:
                    print(f"💿 从缓存获取到 {len(credentials)} 个有效凭据")

                return credentials

        except sqlite3.Error as e:
            print(f"⚠️ 获取缓存凭据失败: {e}")
            return []


# 便捷函数
def fetch_kunpeng_credentials(ip_list: List[str]) -> List[BMCCredentials]:
    """获取Kunpeng Lab凭据的便捷函数"""
    fetcher = CredentialFetcher()
    return fetcher.fetch_credentials(ip_list, 'kunpeng_lab')


def main():
    """测试凭据获取器"""
    try:
        fetcher = CredentialFetcher()

        # 从文件获取凭据
        credentials = fetcher.fetch_from_file("bmc_ip.txt")

        if credentials:
            print(f"\n🎉 获取到 {len(credentials)} 个BMC凭据:")
            for cred in credentials:
                print(f"   - {cred.ip}: {cred.username}@{cred.password}")
        else:
            print("⚠️ 未获取到任何凭据")

    except Exception as e:
        print(f"❌ 凭据获取测试失败: {e}")


if __name__ == "__main__":
    main()