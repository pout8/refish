#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Refish 数据库迁移脚本
浮浮酱精心设计的数据库升级工具 ฅ'ω'ฅ

功能：
- 检查现有 cookies.db 数据库
- 创建新的表结构支持 Redfish 重构
- 迁移现有数据保证向后兼容
- 提供数据验证和回滚能力
"""

import sqlite3
import os
import shutil
from datetime import datetime
from pathlib import Path
import sys


class DatabaseMigrator:
    """数据库迁移管理器 - 负责安全的数据库结构升级"""

    def __init__(self, db_path: str = "cookies.db"):
        self.db_path = Path(db_path)
        self.backup_path = Path(f"{db_path}.backup_{datetime.now().strftime('%Y%m%d_%H%M%S')}")
        self.new_db_path = Path("refish_hardware.db")

    def create_backup(self) -> bool:
        """创建数据库备份"""
        try:
            if self.db_path.exists():
                shutil.copy2(self.db_path, self.backup_path)
                print(f"✅ 数据库备份创建成功: {self.backup_path}")
                return True
            else:
                print("ℹ️  未发现现有数据库，将创建全新数据库")
                return True
        except Exception as e:
            print(f"❌ 备份创建失败: {e}")
            return False

    def check_existing_schema(self) -> dict:
        """检查现有数据库结构"""
        schema_info = {"tables": [], "has_cookies_table": False}

        if not self.db_path.exists():
            print("ℹ️  数据库文件不存在，将创建全新结构")
            return schema_info

        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()

                # 获取所有表
                cursor.execute("SELECT name FROM sqlite_master WHERE type='table';")
                tables = cursor.fetchall()
                schema_info["tables"] = [table[0] for table in tables]

                # 检查 cookies 表
                if "cookies" in schema_info["tables"]:
                    schema_info["has_cookies_table"] = True
                    cursor.execute("SELECT COUNT(*) FROM cookies;")
                    schema_info["cookies_count"] = cursor.fetchone()[0]

                print(f"📊 现有数据库信息:")
                print(f"   - 表数量: {len(schema_info['tables'])}")
                print(f"   - 表列表: {', '.join(schema_info['tables'])}")
                if schema_info["has_cookies_table"]:
                    print(f"   - Cookie 记录数: {schema_info['cookies_count']}")

        except Exception as e:
            print(f"⚠️  检查现有数据库时出错: {e}")

        return schema_info

    def create_new_schema(self) -> bool:
        """创建新的数据库结构"""
        try:
            with sqlite3.connect(self.new_db_path) as conn:
                cursor = conn.cursor()

                # 1. 认证 Cookie 表 (兼容现有结构)
                cursor.execute("""
                CREATE TABLE IF NOT EXISTS auth_cookies (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    account_name TEXT UNIQUE NOT NULL,
                    cookie_data TEXT NOT NULL,
                    last_updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    expires_at TIMESTAMP,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                );
                """)

                # 2. 服务器凭据表 (核心新增)
                cursor.execute("""
                CREATE TABLE IF NOT EXISTS servers (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    bmc_ip TEXT UNIQUE NOT NULL,
                    username TEXT NOT NULL,
                    password TEXT NOT NULL,
                    server_model TEXT,
                    manufacturer TEXT,
                    serial_number TEXT,
                    status TEXT DEFAULT 'unknown',
                    last_verified TIMESTAMP,
                    password_verified BOOLEAN DEFAULT FALSE,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                );
                """)

                # 3. 硬件信息缓存表
                cursor.execute("""
                CREATE TABLE IF NOT EXISTS hardware_cache (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    server_id INTEGER NOT NULL,
                    component_type TEXT NOT NULL,
                    component_data JSON NOT NULL,
                    last_updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    cache_valid BOOLEAN DEFAULT TRUE,
                    FOREIGN KEY (server_id) REFERENCES servers(id) ON DELETE CASCADE,
                    UNIQUE(server_id, component_type)
                );
                """)

                # 4. 内存条详细信息表 (支持排序)
                cursor.execute("""
                CREATE TABLE IF NOT EXISTS memory_modules (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    server_id INTEGER NOT NULL,
                    slot_id TEXT NOT NULL,
                    slot_position INTEGER,
                    module_name TEXT,
                    capacity_gb INTEGER,
                    serial_number TEXT,
                    manufacturer TEXT,
                    part_number TEXT,
                    memory_type TEXT,
                    speed_mhz INTEGER,
                    status TEXT DEFAULT 'unknown',
                    last_detected TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY (server_id) REFERENCES servers(id) ON DELETE CASCADE,
                    UNIQUE(server_id, slot_id)
                );
                """)

                # 5. 操作日志表
                cursor.execute("""
                CREATE TABLE IF NOT EXISTS operation_logs (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    server_id INTEGER,
                    operation_type TEXT NOT NULL,
                    operation_status TEXT NOT NULL,
                    error_message TEXT,
                    execution_time_ms INTEGER,
                    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY (server_id) REFERENCES servers(id) ON DELETE SET NULL
                );
                """)

                # 创建索引
                self._create_indexes(cursor)

                # 创建触发器
                self._create_triggers(cursor)

                conn.commit()
                print("✅ 新数据库结构创建成功！")
                return True

        except Exception as e:
            print(f"❌ 创建新数据库结构失败: {e}")
            return False

    def _create_indexes(self, cursor):
        """创建性能优化索引"""
        indexes = [
            "CREATE INDEX IF NOT EXISTS idx_servers_bmc_ip ON servers(bmc_ip);",
            "CREATE INDEX IF NOT EXISTS idx_servers_status ON servers(status);",
            "CREATE INDEX IF NOT EXISTS idx_memory_server_slot ON memory_modules(server_id, slot_position);",
            "CREATE INDEX IF NOT EXISTS idx_hardware_cache_server_type ON hardware_cache(server_id, component_type);",
            "CREATE INDEX IF NOT EXISTS idx_logs_server_timestamp ON operation_logs(server_id, timestamp);",
        ]

        for index_sql in indexes:
            cursor.execute(index_sql)

        print("✅ 数据库索引创建完成")

    def _create_triggers(self, cursor):
        """创建数据维护触发器"""
        # 自动更新时间戳触发器
        cursor.execute("""
        CREATE TRIGGER IF NOT EXISTS update_servers_timestamp
            AFTER UPDATE ON servers
        BEGIN
            UPDATE servers SET updated_at = CURRENT_TIMESTAMP WHERE id = NEW.id;
        END;
        """)

        # 清理过期缓存触发器
        cursor.execute("""
        CREATE TRIGGER IF NOT EXISTS cleanup_expired_cache
            BEFORE INSERT ON hardware_cache
        BEGIN
            DELETE FROM hardware_cache
            WHERE server_id = NEW.server_id
            AND component_type = NEW.component_type
            AND last_updated < datetime('now', '-1 day');
        END;
        """)

        print("✅ 数据库触发器创建完成")

    def migrate_existing_data(self, schema_info: dict) -> bool:
        """迁移现有数据到新结构"""
        if not schema_info["has_cookies_table"]:
            print("ℹ️  无现有 Cookie 数据需要迁移")
            return True

        try:
            # 从旧数据库读取数据
            with sqlite3.connect(self.db_path) as old_conn:
                old_cursor = old_conn.cursor()
                old_cursor.execute("SELECT account_name, cookie_data, last_updated FROM cookies;")
                cookie_data = old_cursor.fetchall()

            # 写入新数据库
            with sqlite3.connect(self.new_db_path) as new_conn:
                new_cursor = new_conn.cursor()
                for account_name, cookie_data_str, last_updated in cookie_data:
                    new_cursor.execute("""
                    INSERT OR REPLACE INTO auth_cookies (account_name, cookie_data, last_updated)
                    VALUES (?, ?, ?);
                    """, (account_name, cookie_data_str, last_updated))

                new_conn.commit()

            print(f"✅ 成功迁移 {len(cookie_data)} 条 Cookie 记录")
            return True

        except Exception as e:
            print(f"❌ 数据迁移失败: {e}")
            return False

    def validate_migration(self) -> bool:
        """验证迁移结果"""
        try:
            with sqlite3.connect(self.new_db_path) as conn:
                cursor = conn.cursor()

                # 检查所有表是否存在
                cursor.execute("SELECT name FROM sqlite_master WHERE type='table';")
                tables = [row[0] for row in cursor.fetchall()]

                expected_tables = ['auth_cookies', 'servers', 'hardware_cache', 'memory_modules', 'operation_logs']
                missing_tables = [table for table in expected_tables if table not in tables]

                if missing_tables:
                    print(f"❌ 缺少表: {missing_tables}")
                    return False

                # 检查数据完整性
                cursor.execute("SELECT COUNT(*) FROM auth_cookies;")
                cookie_count = cursor.fetchone()[0]

                print(f"✅ 迁移验证通过:")
                print(f"   - 所有表创建成功: {len(expected_tables)} 个")
                print(f"   - Cookie 数据: {cookie_count} 条")

                return True

        except Exception as e:
            print(f"❌ 验证失败: {e}")
            return False

    def run_migration(self) -> bool:
        """执行完整的迁移流程"""
        print("🚀 开始数据库迁移...")
        print("=" * 50)

        # 1. 创建备份
        if not self.create_backup():
            return False

        # 2. 检查现有结构
        schema_info = self.check_existing_schema()

        # 3. 创建新结构
        if not self.create_new_schema():
            return False

        # 4. 迁移数据
        if not self.migrate_existing_data(schema_info):
            return False

        # 5. 验证结果
        if not self.validate_migration():
            return False

        print("=" * 50)
        print("🎉 数据库迁移完成！")
        print(f"📁 新数据库: {self.new_db_path}")
        print(f"📁 备份文件: {self.backup_path}")

        return True


def main():
    """主函数"""
    print("Refish 数据库迁移工具")
    print("浮浮酱制作 ฅ'ω'ฅ")
    print()

    # 用户确认
    confirm = input("确认开始数据库迁移？这将创建新的数据库结构 (y/N): ").strip().lower()
    if confirm not in ['y', 'yes', '是']:
        print("❌ 迁移已取消")
        return

    # 执行迁移
    migrator = DatabaseMigrator()
    success = migrator.run_migration()

    if success:
        print("\n✅ 迁移成功！现在可以使用新的 Refish 系统了")
        sys.exit(0)
    else:
        print("\n❌ 迁移失败！请检查错误信息")
        sys.exit(1)


if __name__ == "__main__":
    main()