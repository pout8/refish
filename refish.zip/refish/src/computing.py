import requests
import json
import urllib3
from pathlib import Path
import sqlite3
from datetime import datetime
import sys

# --- 配置 ---
DB_PATH = Path("cookies.db")
BASE_ACCOUNT_NAME = "h60099082"  # W3 SSO Cookie
KUNPENG_ACCOUNT_NAME = f"{BASE_ACCOUNT_NAME}_kunpeng_lab"  # Kunpeng Lab专用Cookie
GROUP_ID = "paddde0df492d4f9487ac491ad2f4c501"  # 固定的资源组ID

# 禁用SSL警告
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)


# --- 数据库操作 (重构为类) ---
class CookieManager:
    """
    负责管理存储在SQLite数据库中的Cookie。
    假定数据库文件和'cookies'表已经存在。
    """

    def __init__(self, db_path: Path):
        self.db_path = db_path
        if not self.db_path.exists():
            print(f"[致命错误] 数据库文件不存在: {self.db_path}")
            print("请先运行初始化脚本创建数据库。")
            sys.exit(1) # 终止脚本

    def get_cookie(self, account_name: str) -> str | None:
        """从数据库获取Cookie"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                cursor.execute("SELECT cookie_data FROM cookies WHERE account_name = ?", (account_name,))
                result = cursor.fetchone()
                return result[0] if result else None
        except sqlite3.OperationalError as e:
            print(f"[致命错误] 数据库查询失败: {e}")
            print("请确保 'cookies' 表已在数据库中创建。")
            sys.exit(1) # 终止脚本

    def save_cookie(self, account_name: str, cookie_data: str):
        """保存或更新Cookie到数据库"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                now = datetime.now().isoformat()
                cursor.execute("""
                               INSERT INTO cookies (account_name, cookie_data, last_updated)
                               VALUES (?, ?, ?) ON CONFLICT(account_name) DO
                               UPDATE SET
                                   cookie_data = excluded.cookie_data,
                                   last_updated = excluded.last_updated;
                               """, (account_name, cookie_data, now))
                conn.commit()
        except sqlite3.OperationalError as e:
            print(f"[致命错误] 数据库写入失败: {e}")
            print("请确保 'cookies' 表已在数据库中创建。")
            sys.exit(1) # 终止脚本

# --- 核心网络和辅助函数 ---

def load_cookie_string_to_session(session, cookie_string):
    """将Cookie字符串解析并加载到session的CookieJar中。"""
    if not cookie_string:
        return
    cookies_dict = {c.split('=')[0].strip(): c.split('=', 1)[1].strip() for c in cookie_string.split(';')}
    for name, value in cookies_dict.items():
        session.cookies.set(name, value)


def read_ips_from_file(filename="bmc_ip.txt"):
    """从文件中读取IP地址列表"""
    try:
        ip_path = Path(filename)
        if not ip_path.exists():
            return []
        lines = ip_path.read_text(encoding='utf-8').splitlines()
        return [line.strip() for line in lines if line.strip()]
    except Exception as e:
        print(f"[错误] 读取IP文件时出错: {e}")
        return []


def initialize_app_session(session):
    """使用主Cookie初始化Kunpeng Lab的应用级会话"""
    print("[*] 正在初始化 Kunpeng Lab 的会话 (慢速路径)...")
    url = "https://kunpeng-lab.server.huawei.com/v1/system/user/login"
    try:
        response = session.post(url, verify=False, timeout=15)
        response.raise_for_status()
        print("[成功] Kunpeng Lab 会话初始化成功！")
        return True
    except requests.exceptions.RequestException as e:
        print(f"[严重错误] 初始化Kunpeng Lab会话失败: {e}")
        return False


def search_bmc_ips(session, ip_list):
    """批量搜索BMC IP信息"""
    print(f"[*] 正在批量搜索 {len(ip_list)} 个IP地址...")
    url = "https://kunpeng-lab.server.huawei.com/v1/resource/server/get-server"
    payload = {"data": {"bmc_ip": ip_list}, "data_range": 1, "start_date": "2025-09-06", "end_date": "2025-09-12",
               "limit": len(ip_list) + 10, "offset": 1}
    try:
        response = session.post(url, json=payload, verify=False, timeout=30)
        response.raise_for_status()
        data = response.json()
        if data.get('status_code') == 200:
            return data.get('data', {}).get('res', [])
        else:
            print(f"[警告] API返回状态码非200: {data.get('status_code')} - {data.get('msg')}")
            return None
    except requests.exceptions.RequestException as e:
        print(f"[严重错误] 批量搜索IP时网络请求失败: {e}")
        return None
    except json.JSONDecodeError:
        print(f"[严重错误] 无法解析搜索IP的响应。原始文本: {response.text}")
        return None


def get_bmc_password(session, server_id, group_id):
    """获取指定服务器的BMC密码"""
    url = "https://kunpeng-lab.server.huawei.com/v1/resource/server/get-password"
    payload = {"id": server_id, "group_id": group_id, "password_type": "bmc", "resource_type": 0}
    try:
        response = session.post(url, json=payload, verify=False, timeout=15)
        response.raise_for_status()
        data = response.json()
        return data.get('data', {}).get('res')
    except Exception as e:
        print(f"    [错误] 获取密码时发生错误: {e}")
        return None


def main():
    """主执行函数"""
    print("--- BMC信息查询脚本启动 ---")

    # 初始化Cookie管理器，它将处理所有数据库交互
    cookie_manager = CookieManager(DB_PATH)

    # 创建会话并设置必要的默认请求头
    session = requests.Session()
    session.headers.update({
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36",
        "Origin": "https://computing.lab.rnd.huawei.com",
        "Referer": "https://computing.lab.rnd.huawei.com/",
        "groupId": GROUP_ID
    })

    # --- 智能认证流程 ---
    cached_cookie = cookie_manager.get_cookie(KUNPENG_ACCOUNT_NAME)
    if cached_cookie:
        print(f"[*] 尝试使用缓存的专用Cookie '{KUNPENG_ACCOUNT_NAME}' (快速路径)...")
        load_cookie_string_to_session(session, cached_cookie)
    else:
        print("[!] 未找到专用Cookie，回退至两步初始化...")
        base_cookie = cookie_manager.get_cookie(BASE_ACCOUNT_NAME)
        if not base_cookie:
            print(f"[致命错误] 基础SSO Cookie '{BASE_ACCOUNT_NAME}' 未在数据库中找到。请先运行登录脚本获取。")
            return

        load_cookie_string_to_session(session, base_cookie)

        if not initialize_app_session(session):
            return

        updated_cookie_string = "; ".join([f"{c.name}={c.value}" for c in session.cookies])

        if updated_cookie_string:
            cookie_manager.save_cookie(KUNPENG_ACCOUNT_NAME, updated_cookie_string)
            print(f"[信息] 新的专用会话Cookie已保存到数据库，账户为 '{KUNPENG_ACCOUNT_NAME}'。")
        else:
            print("[警告] 未能从会话中提取到有效的Cookie字符串进行保存。")

    # --- 执行查询 ---
    ip_list = read_ips_from_file("bmc_ip.txt")
    if not ip_list:
        print("[信息] IP文件为空或不存在，脚本结束。")
        return

    found_servers = search_bmc_ips(session, ip_list)

    if found_servers is None:
        print("[!] 搜索IP失败或API返回错误。")
        return

    if not found_servers:
        print("--- API返回结果为空 ---")
        print("所有查询的IP均未在返回结果中找到。")
        return

    print("\n--- 处理已找到的服务器 ---")
    found_ips = {server.get('bmc_ip') for server in found_servers if server.get('bmc_ip')}

    for server in found_servers:
        bmc_ip = server.get('bmc_ip', '未知IP')
        print("------------------------------")
        print(f"[*] 正在处理服务器: {bmc_ip}")

        net_status = server.get('net_status', {})
        if net_status.get('id') != 0:
            print(f"[警告] IP: {bmc_ip} - 网络状态异常: {net_status.get('name', '未知状态')}")
            continue
        print(f"[成功] IP: {bmc_ip} - 网络状态正常。")

        server_id = server.get('id')
        group_id = server.get('group_id')
        if not (server_id and group_id):
            print(f"[错误] IP: {bmc_ip} - 缺少'id'或'group_id'，无法获取密码。")
            continue

        password = get_bmc_password(session, server_id, group_id)
        if password:
            print(f"[成功] IP: {bmc_ip} - 成功获取密码: {password}")
        else:
            print(f"[失败] IP: {bmc_ip} - 未能获取到密码。")

    print("\n--- 未找到的服务器IP ---")
    unfound_ips = set(ip_list) - found_ips
    if unfound_ips:
        for ip in unfound_ips:
            print(f"[未找到] IP: {ip}")
    else:
        print("所有查询的IP都已在返回结果中处理。")


if __name__ == "__main__":
    main()
