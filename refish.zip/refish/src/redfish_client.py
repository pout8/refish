#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Refish 增强版 Redfish 客户端
浮浮酱精心重构的通用硬件信息获取系统 ฅ'ω'ฅ

特性:
- 内存按槽位智能排序 (华为 000→010→011 格式)
- 集成统一认证和凭据管理
- 多厂商 Redfish 标准支持
- 异步高性能处理
- 结构化数据输出
- 错误重试和恢复机制
"""

import asyncio
import json
import re
import sys
from typing import Dict, Any, List, Optional, Union, Tuple
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from datetime import datetime
import aiohttp

# 导入我们的模块
from credential_fetcher import CredentialFetcher, BMCCredentials
from auth_manager import AuthManager


class HardwareType(Enum):
    """硬件类型枚举"""
    SYSTEM = "system"
    CPU = "cpu"
    MEMORY = "memory"
    STORAGE = "storage"
    PCIE = "pcie"
    ALL = "all"


@dataclass
class MemorySlot:
    """内存槽位信息"""
    slot_id: str
    name: str
    capacity_gb: int
    serial_number: str
    location: str
    sort_order: int = 0

    def __post_init__(self):
        """计算排序顺序"""
        self.sort_order = self._calculate_sort_order()

    def _calculate_sort_order(self) -> int:
        """
        计算内存槽位排序顺序
        华为格式: 000 → 0, 010 → 10, 011 → 11
        Dell格式: DIMM_A1 → 1001, DIMM_B1 → 2001
        HP格式: PROC_1_DIMM_1 → 1001
        """
        slot_name = self.slot_id.upper()

        # 华为格式: 000, 010, 011
        if re.match(r'^\d{3}$', slot_name):
            return int(slot_name)

        # Dell格式: DIMM_A1, DIMM_B1
        dell_match = re.match(r'^DIMM_([A-Z])(\d+)$', slot_name)
        if dell_match:
            letter, number = dell_match.groups()
            letter_value = ord(letter) - ord('A') + 1
            return letter_value * 1000 + int(number)

        # HP格式: PROC_1_DIMM_1
        hp_match = re.match(r'^PROC_(\d+)_DIMM_(\d+)$', slot_name)
        if hp_match:
            proc_num, dimm_num = hp_match.groups()
            return int(proc_num) * 1000 + int(dimm_num)

        # 通用数字提取
        numbers = re.findall(r'\d+', slot_name)
        if numbers:
            return int(numbers[-1])

        # 默认按字母排序
        return hash(slot_name) % 10000


@dataclass
class HardwareInfo:
    """硬件信息汇总"""
    server_ip: str
    timestamp: datetime = field(default_factory=datetime.now)
    manufacturer: str = "N/A"
    model: str = "N/A"
    serial_number: str = "N/A"
    bios_version: str = "N/A"
    power_state: str = "N/A"
    health_status: str = "N/A"
    cpu_count: int = 0
    cpu_details: List[str] = field(default_factory=list)
    memory_slots: List[MemorySlot] = field(default_factory=list)
    storage_devices: List[str] = field(default_factory=list)
    pcie_devices: List[str] = field(default_factory=list)
    raw_data: Dict[str, Any] = field(default_factory=dict)

    @property
    def total_memory_gb(self) -> int:
        """计算总内存容量"""
        return sum(slot.capacity_gb for slot in self.memory_slots if slot.capacity_gb > 0)

    @property
    def sorted_memory_slots(self) -> List[MemorySlot]:
        """返回按槽位排序的内存列表"""
        return sorted(self.memory_slots, key=lambda slot: slot.sort_order)

    def to_dict(self) -> Dict[str, Any]:
        """转换为字典格式"""
        return {
            'server_ip': self.server_ip,
            'timestamp': self.timestamp.isoformat(),
            'manufacturer': self.manufacturer,
            'model': self.model,
            'serial_number': self.serial_number,
            'bios_version': self.bios_version,
            'power_state': self.power_state,
            'health_status': self.health_status,
            'cpu_count': self.cpu_count,
            'cpu_details': self.cpu_details,
            'total_memory_gb': self.total_memory_gb,
            'memory_slots': [slot.__dict__ for slot in self.sorted_memory_slots],
            'storage_devices': self.storage_devices,
            'pcie_devices': self.pcie_devices,
        }


class RedfishClient:
    """
    增强版 Redfish 客户端
    遵循单一职责原则 - 专注于 Redfish API 交互
    """

    def __init__(self, target_ip: str, username: str, password: str,
                 timeout: int = 30, max_retries: int = 3):
        self.target_ip = target_ip
        self.username = username
        self.password = password
        self.timeout = timeout
        self.max_retries = max_retries
        self.base_url = f"https://{target_ip}"
        self.session: Optional[aiohttp.ClientSession] = None

    async def __aenter__(self):
        """异步上下文管理器入口"""
        connector = aiohttp.TCPConnector(ssl=False, limit=100)
        timeout = aiohttp.ClientTimeout(total=self.timeout)
        self.session = aiohttp.ClientSession(
            connector=connector,
            timeout=timeout,
            auth=aiohttp.BasicAuth(self.username, self.password)
        )
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """异步上下文管理器退出"""
        if self.session:
            await self.session.close()

    async def get(self, path: str, retries: Optional[int] = None) -> Optional[Dict[str, Any]]:
        """
        执行 GET 请求，支持重试机制

        Args:
            path: API 路径
            retries: 重试次数，默认使用类设置

        Returns:
            JSON 响应数据或 None
        """
        if not self.session:
            raise RuntimeError("Session not initialized. Use async context manager.")

        retries = retries if retries is not None else self.max_retries
        url = f"{self.base_url}{path}"

        for attempt in range(retries + 1):
            try:
                async with self.session.get(url) as response:
                    if response.status == 200:
                        return await response.json()
                    elif response.status == 401:
                        print(f"❌ 认证失败 ({self.target_ip}): 请检查用户名密码")
                        return None
                    elif response.status == 404:
                        # 404 是正常的，某些路径可能不存在
                        return None
                    else:
                        if attempt < retries:
                            print(f"⚠️ 请求失败 ({response.status}), 重试中... ({attempt + 1}/{retries})")
                            await asyncio.sleep(1)
                            continue
                        else:
                            print(f"❌ 请求失败 ({self.target_ip}): HTTP {response.status}")
                            return None

            except aiohttp.ClientConnectorError:
                if attempt < retries:
                    print(f"⚠️ 连接失败，重试中... ({attempt + 1}/{retries})")
                    await asyncio.sleep(2)
                else:
                    print(f"❌ 无法连接到 {self.target_ip}")
                return None

            except asyncio.TimeoutError:
                if attempt < retries:
                    print(f"⚠️ 请求超时，重试中... ({attempt + 1}/{retries})")
                    await asyncio.sleep(1)
                else:
                    print(f"❌ 请求超时: {self.target_ip}")
                return None

            except Exception as e:
                print(f"❌ 请求异常 ({self.target_ip}): {e}")
                return None

        return None

    async def get_paginated(self, initial_path: str) -> List[Dict[str, Any]]:
        """
        处理分页响应，获取所有成员

        Args:
            initial_path: 初始请求路径

        Returns:
            所有成员的列表
        """
        all_members = []
        next_link = initial_path

        while next_link:
            page_data = await self.get(next_link)
            if not page_data:
                break

            if 'Members' in page_data:
                all_members.extend(page_data['Members'])

            # 获取下一页链接
            next_link = page_data.get('Members@odata.nextLink')

        return all_members


class HardwareCollector:
    """
    硬件信息收集器
    遵循单一职责原则 - 专注于硬件信息的收集和格式化
    """

    def __init__(self, client: RedfishClient):
        self.client = client

    async def collect_all(self) -> HardwareInfo:
        """收集所有硬件信息"""
        info = HardwareInfo(server_ip=self.client.target_ip)

        # 并行收集基础信息
        system_task = self.collect_system_info(info)
        cpu_task = self.collect_cpu_info(info)
        memory_task = self.collect_memory_info(info)
        storage_task = self.collect_storage_info(info)
        pcie_task = self.collect_pcie_info(info)

        await asyncio.gather(
            system_task, cpu_task, memory_task,
            storage_task, pcie_task,
            return_exceptions=True
        )

        return info

    async def collect_system_info(self, info: HardwareInfo):
        """收集系统基础信息"""
        data = await self.client.get('/redfish/v1/Systems/1/')
        if data:
            info.manufacturer = data.get('Manufacturer', 'N/A')
            info.model = data.get('Model', 'N/A')
            info.serial_number = data.get('SerialNumber', 'N/A')
            info.bios_version = data.get('BiosVersion', 'N/A')
            info.power_state = data.get('PowerState', 'N/A')
            status = data.get('Status', {})
            info.health_status = status.get('Health', 'N/A')
            info.raw_data['system'] = data

    async def collect_cpu_info(self, info: HardwareInfo):
        """收集CPU信息"""
        processors_list = await self.client.get('/redfish/v1/Systems/1/Processors/')
        if not processors_list or 'Members' not in processors_list:
            return

        # 分离CPU和NPU
        cpu_paths = []
        npu_count = 0

        for member in processors_list['Members']:
            odata_id = member.get('@odata.id', '')
            if 'Npu' in odata_id:
                npu_count += 1
            else:
                cpu_paths.append(odata_id)

        info.cpu_count = len(cpu_paths)

        # 并行获取CPU详细信息
        if cpu_paths:
            cpu_tasks = [self.client.get(path) for path in cpu_paths]
            results = await asyncio.gather(*cpu_tasks, return_exceptions=True)

            for result in results:
                if isinstance(result, dict):
                    name = result.get('Name', 'N/A')
                    model = result.get('Model', 'N/A')
                    sn = result.get('Oem', {}).get('Huawei', {}).get('SerialNumber', 'N/A')
                    info.cpu_details.append(f"[{name}] 型号: {model}, SN: {sn}")

        info.raw_data['processors'] = {'cpu_count': len(cpu_paths), 'npu_count': npu_count}

    async def collect_memory_info(self, info: HardwareInfo):
        """收集内存信息并按槽位排序"""
        # 使用分页获取所有内存成员
        all_members = await self.client.get_paginated('/redfish/v1/Systems/1/Memory/')

        if not all_members:
            return

        # 并行获取内存详细信息
        memory_tasks = [
            self.client.get(member['@odata.id'])
            for member in all_members
            if '@odata.id' in member
        ]

        results = await asyncio.gather(*memory_tasks, return_exceptions=True)

        for result in results:
            if isinstance(result, dict):
                name = result.get('Name', 'N/A')
                slot_id = self._extract_slot_id(name, result)
                capacity_mib = result.get('CapacityMiB', 0)
                capacity_gb = round(capacity_mib / 1024) if capacity_mib else 0
                serial_number = result.get('SerialNumber', 'N/A')
                location = result.get('DeviceLocator', name)

                memory_slot = MemorySlot(
                    slot_id=slot_id,
                    name=name,
                    capacity_gb=capacity_gb,
                    serial_number=serial_number,
                    location=location
                )

                info.memory_slots.append(memory_slot)

        info.raw_data['memory'] = {
            'total_slots': len(info.memory_slots),
            'total_capacity_gb': info.total_memory_gb
        }

    def _extract_slot_id(self, name: str, data: Dict[str, Any]) -> str:
        """从内存数据中提取槽位ID"""
        # 优先使用DeviceLocator
        device_locator = data.get('DeviceLocator')
        if device_locator and device_locator != 'N/A':
            return device_locator

        # 从Name中提取
        if name and name != 'N/A':
            # 提取类似 "DIMM 000" 中的槽位号
            slot_match = re.search(r'(\d{3}|[A-Z]+\d+)', name)
            if slot_match:
                return slot_match.group(1)

        # 从OEM信息中提取 (华为特定)
        oem_info = data.get('Oem', {}).get('Huawei', {})
        slot_info = oem_info.get('Position')
        if slot_info:
            return str(slot_info)

        return name

    async def collect_storage_info(self, info: HardwareInfo):
        """收集存储设备信息"""
        # 优先从Chassis获取
        drives_data = await self.client.get('/redfish/v1/Chassis/1/Drives/')
        drive_paths = set()

        if drives_data and 'Members' in drives_data:
            for member in drives_data['Members']:
                if '@odata.id' in member:
                    drive_paths.add(member['@odata.id'])

        # 回退到Storage控制器
        if not drive_paths:
            storage_list = await self.client.get('/redfish/v1/Systems/1/Storages/')
            if storage_list and 'Members' in storage_list:
                storage_tasks = [
                    self.client.get(member['@odata.id'])
                    for member in storage_list['Members']
                ]
                storage_results = await asyncio.gather(*storage_tasks, return_exceptions=True)

                for result in storage_results:
                    if isinstance(result, dict) and 'Drives' in result:
                        for drive_member in result['Drives']:
                            if isinstance(drive_member, dict) and '@odata.id' in drive_member:
                                drive_paths.add(drive_member['@odata.id'])

        if drive_paths:
            drive_tasks = [self.client.get(path) for path in sorted(drive_paths)]
            results = await asyncio.gather(*drive_tasks, return_exceptions=True)

            for result in results:
                if isinstance(result, dict):
                    name = result.get('Name', 'N/A')
                    model = result.get('Model', 'N/A')
                    capacity_bytes = result.get('CapacityBytes')
                    size_gb = f"{round(capacity_bytes / (1024 ** 3))} GB" if capacity_bytes else "N/A"
                    media_type = result.get('MediaType', 'N/A')
                    sn = result.get('SerialNumber', 'N/A')

                    device_info = f"[{name}] 型号: {model}, 容量: {size_gb}, 类型: {media_type}, SN: {sn}"
                    info.storage_devices.append(device_info)

        info.raw_data['storage'] = {'device_count': len(info.storage_devices)}

    async def collect_pcie_info(self, info: HardwareInfo):
        """收集PCIe设备信息"""
        device_paths = set()

        # 从系统信息获取PCIe设备
        system_data = await self.client.get('/redfish/v1/Systems/1/')
        if system_data and 'PCIeDevices' in system_data:
            for member in system_data['PCIeDevices']:
                if '@odata.id' in member:
                    device_paths.add(member['@odata.id'])

        # 从存储控制器关联的板卡获取
        storage_list = await self.client.get('/redfish/v1/Systems/1/Storages/')
        if storage_list and 'Members' in storage_list:
            storage_tasks = [
                self.client.get(member['@odata.id'])
                for member in storage_list['Members']
            ]
            storage_results = await asyncio.gather(*storage_tasks, return_exceptions=True)

            for result in storage_results:
                if isinstance(result, dict) and 'StorageControllers' in result:
                    for controller in result['StorageControllers']:
                        card_path = controller.get('Oem', {}).get('Huawei', {}).get('AssociatedCard', {}).get('@odata.id')
                        if card_path:
                            device_paths.add(card_path)

        if device_paths:
            device_tasks = [self.client.get(path) for path in sorted(device_paths)]
            results = await asyncio.gather(*device_tasks, return_exceptions=True)

            for result in results:
                if isinstance(result, dict):
                    name = result.get('Name', 'N/A')
                    desc = result.get('ProductName', result.get('Description', 'N/A'))
                    sn = result.get('SerialNumber', 'N/A')
                    device_type = "RAID卡" if "RAID" in (name + desc).upper() else "PCIe卡"

                    device_info = f"[{name}] 类型: {device_type}, 描述: {desc}, SN: {sn}"
                    info.pcie_devices.append(device_info)

        info.raw_data['pcie'] = {'device_count': len(info.pcie_devices)}


class RedfishManager:
    """
    Redfish 管理器 - 统一的硬件信息管理接口
    集成认证、凭据获取和硬件信息收集
    """

    def __init__(self, db_path: str = "refish_hardware.db"):
        self.credential_fetcher = CredentialFetcher(db_path)

    async def collect_hardware_info(self, ip_list: List[str],
                                    hardware_types: List[HardwareType] = None) -> Dict[str, HardwareInfo]:
        """
        批量收集硬件信息

        Args:
            ip_list: IP地址列表
            hardware_types: 要收集的硬件类型列表

        Returns:
            IP到硬件信息的映射
        """
        if hardware_types is None:
            hardware_types = [HardwareType.ALL]

        # 获取凭据
        print(f"🔑 获取 {len(ip_list)} 个服务器的凭据...")
        credentials = self.credential_fetcher.fetch_credentials(ip_list)

        if not credentials:
            print("❌ 未获取到任何有效凭据")
            return {}

        # 创建收集任务
        print(f"📡 开始收集 {len(credentials)} 个服务器的硬件信息...")
        tasks = []

        for cred in credentials:
            task = self._collect_single_server(cred, hardware_types)
            tasks.append(task)

        # 并行执行
        results = await asyncio.gather(*tasks, return_exceptions=True)

        # 处理结果
        hardware_info = {}
        for i, result in enumerate(results):
            if isinstance(result, HardwareInfo):
                hardware_info[result.server_ip] = result
                print(f"✅ {result.server_ip} - 硬件信息收集完成")
            else:
                cred = credentials[i]
                print(f"❌ {cred.ip} - 硬件信息收集失败: {result}")

        return hardware_info

    async def _collect_single_server(self, credential: BMCCredentials,
                                     hardware_types: List[HardwareType]) -> HardwareInfo:
        """收集单个服务器的硬件信息"""
        async with RedfishClient(
            credential.ip,
            credential.username,
            credential.password
        ) as client:
            collector = HardwareCollector(client)
            return await collector.collect_all()

    def print_hardware_info(self, hardware_info: Dict[str, HardwareInfo],
                            format_type: str = "table"):
        """
        格式化打印硬件信息

        Args:
            hardware_info: 硬件信息字典
            format_type: 输出格式 (table, json, detailed)
        """
        if format_type == "json":
            self._print_json_format(hardware_info)
        elif format_type == "detailed":
            self._print_detailed_format(hardware_info)
        else:
            self._print_table_format(hardware_info)

    def _print_table_format(self, hardware_info: Dict[str, HardwareInfo]):
        """表格格式输出"""
        print("\n" + "="*100)
        print("🖥️  REFISH 硬件信息汇总 (浮浮酱制作)")
        print("="*100)

        for ip, info in hardware_info.items():
            print(f"\n📍 服务器: {ip}")
            print(f"   制造商: {info.manufacturer}")
            print(f"   型号: {info.model}")
            print(f"   序列号: {info.serial_number}")
            print(f"   CPU数量: {info.cpu_count}")
            print(f"   内存总量: {info.total_memory_gb} GB ({len(info.memory_slots)} 个槽位)")
            print(f"   存储设备: {len(info.storage_devices)} 个")
            print(f"   PCIe设备: {len(info.pcie_devices)} 个")
            print(f"   健康状态: {info.health_status}")

            # 显示排序后的内存槽位
            if info.memory_slots:
                print(f"\n   💾 内存槽位详情 (按槽位排序):")
                for slot in info.sorted_memory_slots:
                    print(f"     - 槽位 {slot.slot_id}: {slot.capacity_gb} GB (SN: {slot.serial_number})")

    def _print_detailed_format(self, hardware_info: Dict[str, HardwareInfo]):
        """详细格式输出"""
        for ip, info in hardware_info.items():
            print(f"\n{'='*80}")
            print(f"🖥️  服务器详细信息: {ip}")
            print(f"{'='*80}")

            print(f"\n--- 系统信息 ---")
            print(f"  制造商: {info.manufacturer}")
            print(f"  型号: {info.model}")
            print(f"  序列号: {info.serial_number}")
            print(f"  BIOS版本: {info.bios_version}")
            print(f"  电源状态: {info.power_state}")
            print(f"  健康状态: {info.health_status}")

            print(f"\n--- CPU信息 ---")
            print(f"  CPU数量: {info.cpu_count}")
            for cpu_detail in info.cpu_details:
                print(f"  - {cpu_detail}")

            print(f"\n--- 内存信息 (按槽位排序) ---")
            print(f"  总容量: {info.total_memory_gb} GB")
            print(f"  槽位数量: {len(info.memory_slots)}")
            for slot in info.sorted_memory_slots:
                print(f"  - 槽位 {slot.slot_id}: {slot.capacity_gb} GB, SN: {slot.serial_number}")

            print(f"\n--- 存储设备 ---")
            print(f"  设备数量: {len(info.storage_devices)}")
            for device in info.storage_devices:
                print(f"  - {device}")

            print(f"\n--- PCIe设备 ---")
            print(f"  设备数量: {len(info.pcie_devices)}")
            for device in info.pcie_devices:
                print(f"  - {device}")

    def _print_json_format(self, hardware_info: Dict[str, HardwareInfo]):
        """JSON格式输出"""
        json_data = {ip: info.to_dict() for ip, info in hardware_info.items()}
        print(json.dumps(json_data, indent=2, ensure_ascii=False))


# 便捷函数
async def collect_server_hardware(ip_list: List[str]) -> Dict[str, HardwareInfo]:
    """收集服务器硬件信息的便捷函数"""
    manager = RedfishManager()
    return await manager.collect_hardware_info(ip_list)


async def main():
    """测试 Redfish 客户端"""
    try:
        manager = RedfishManager()

        # 示例IP列表 (实际使用时从文件或参数获取)
        test_ips = ["192.168.1.100", "192.168.1.101"]  # 替换为实际IP

        hardware_info = await manager.collect_hardware_info(test_ips)

        if hardware_info:
            print(f"\n🎉 成功收集到 {len(hardware_info)} 个服务器的硬件信息")
            manager.print_hardware_info(hardware_info, "detailed")
        else:
            print("⚠️ 未收集到任何硬件信息")

    except Exception as e:
        print(f"❌ 硬件信息收集测试失败: {e}")


if __name__ == "__main__":
    asyncio.run(main())