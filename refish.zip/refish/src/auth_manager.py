#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Refish 认证管理器
浮浮酱精心重构的安全认证系统 ฅ'ω'ฅ

特性:
- 安全的凭据管理 (环境变量优先)
- 可扩展的认证提供器模式
- 统一的会话管理
- 错误处理和重试机制
- 配置外部化
"""

import os
import sqlite3
import requests
import urllib3
from datetime import datetime, timedelta
from typing import Optional, Dict, Any, Protocol
from pathlib import Path
import json
import time

# 禁用SSL警告 (仅用于开发环境)
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)


class AuthProvider(Protocol):
    """认证提供器接口 - 遵循开放/封闭原则"""

    def authenticate(self, credentials: Dict[str, Any]) -> requests.Session:
        """执行认证并返回会话"""
        ...

    def is_session_valid(self, session: requests.Session) -> bool:
        """检查会话是否有效"""
        ...


class HuaweiW3AuthProvider:
    """华为 W3 SSO 认证提供器"""

    def __init__(self, config: Optional[Dict[str, Any]] = None):
        self.config = config or {}
        self.login_url = self.config.get(
            'login_url',
            'https://login.huawei.com/login1/rest/hwidcenter/login'
        )
        self.user_agent = self.config.get(
            'user_agent',
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
        )

    def authenticate(self, credentials: Dict[str, Any]) -> requests.Session:
        """执行华为 W3 SSO 认证"""
        login_account = credentials.get('username')
        password = credentials.get('password')

        if not login_account or not password:
            raise ValueError("华为认证需要用户名和密码")

        session = requests.Session()

        # 设置请求头
        session.headers.update({
            "Content-Type": "application/json;charset=UTF-8",
            "Referer": "https://w3.huawei.com/",
            "User-Agent": self.user_agent
        })

        # 构建登录数据
        login_data = {
            "loginAccount": login_account,
            "password": password,
            "uid": login_account,
            "targetUrl": "https%3A%2F%2Fw3.huawei.com%2Fnext%2Findexa.html",
        }

        try:
            response = session.post(
                self.login_url,
                json=login_data,
                verify=False,
                timeout=30
            )
            response.raise_for_status()

            # 验证登录响应
            if not self._is_login_successful(response, session):
                raise RuntimeError("登录失败: 响应中未发现有效的认证令牌")

            return session

        except requests.exceptions.RequestException as e:
            raise RuntimeError(f"华为 W3 认证失败: {e}")

    def _is_login_successful(self, response: requests.Response, session: requests.Session) -> bool:
        """验证登录是否成功"""
        # 检查是否有cookie
        if not session.cookies:
            return False

        # 检查响应状态
        if response.status_code != 200:
            return False

        # 可以根据实际API响应添加更多验证逻辑
        return True

    def is_session_valid(self, session: requests.Session) -> bool:
        """检查华为会话是否有效"""
        if not session.cookies:
            return False

        # 简单检查关键cookie是否存在
        # 实际实现中可以发送测试请求验证
        return len(session.cookies) > 0


class AuthManager:
    """
    统一认证管理器
    遵循单一职责原则 - 只负责认证相关操作
    """

    def __init__(self, db_path: str = "refish_hardware.db"):
        self.db_path = Path(db_path)
        self.providers: Dict[str, AuthProvider] = {}
        self.sessions: Dict[str, requests.Session] = {}

        # 注册认证提供器
        self._register_providers()

        # 确保数据库表存在
        self._ensure_auth_table()

    def _register_providers(self):
        """注册认证提供器 - 遵循依赖倒置原则"""
        self.providers['huawei_w3'] = HuaweiW3AuthProvider()

    def _ensure_auth_table(self):
        """确保认证表存在"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                # 检查 auth_cookies 表是否存在
                cursor.execute("""
                    SELECT name FROM sqlite_master
                    WHERE type='table' AND name='auth_cookies'
                """)

                if not cursor.fetchone():
                    # 创建表
                    cursor.execute("""
                        CREATE TABLE auth_cookies (
                            id INTEGER PRIMARY KEY AUTOINCREMENT,
                            provider TEXT NOT NULL,
                            account_name TEXT NOT NULL,
                            cookie_data TEXT NOT NULL,
                            last_updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                            expires_at TIMESTAMP,
                            is_active BOOLEAN DEFAULT 1,
                            UNIQUE(provider, account_name)
                        )
                    """)
                    print("✅ 认证表创建成功")

        except sqlite3.Error as e:
            print(f"❌ 数据库操作失败: {e}")

    def authenticate(self, provider_name: str, credentials: Optional[Dict[str, Any]] = None) -> requests.Session:
        """
        执行认证

        Args:
            provider_name: 认证提供器名称 (如 'huawei_w3')
            credentials: 认证凭据，如果为None则从环境变量获取

        Returns:
            认证后的会话对象
        """
        # 获取凭据
        if credentials is None:
            credentials = self._get_credentials_from_env(provider_name)

        # 检查是否有缓存的有效会话
        session_key = f"{provider_name}_{credentials.get('username', 'unknown')}"
        if session_key in self.sessions:
            session = self.sessions[session_key]
            provider = self.providers.get(provider_name)
            if provider and provider.is_session_valid(session):
                print(f"✅ 使用缓存的 {provider_name} 会话")
                return session

        # 执行新的认证
        if provider_name not in self.providers:
            raise ValueError(f"不支持的认证提供器: {provider_name}")

        provider = self.providers[provider_name]

        print(f"🔐 正在进行 {provider_name} 认证...")
        session = provider.authenticate(credentials)

        # 缓存会话
        self.sessions[session_key] = session

        # 保存到数据库
        self._save_session_to_db(provider_name, credentials.get('username'), session)

        print(f"✅ {provider_name} 认证成功")
        return session

    def _get_credentials_from_env(self, provider_name: str) -> Dict[str, Any]:
        """从环境变量获取凭据 - 安全优先"""
        if provider_name == 'huawei_w3':
            username = os.getenv('HUAWEI_LOGIN_ACCOUNT')
            password = os.getenv('HUAWEI_PASSWORD')

            if not username or not password:
                raise ValueError(
                    "华为认证凭据未配置，请设置环境变量:\n"
                    "export HUAWEI_LOGIN_ACCOUNT='your_account'\n"
                    "export HUAWEI_PASSWORD='your_password'"
                )

            return {'username': username, 'password': password}

        raise ValueError(f"不支持的认证提供器: {provider_name}")

    def _save_session_to_db(self, provider_name: str, username: str, session: requests.Session):
        """保存会话到数据库"""
        if not session.cookies:
            return

        # 转换cookie为字符串
        cookie_string = "; ".join([f"{key}={value}" for key, value in session.cookies.items()])

        # 计算过期时间 (默认24小时)
        expires_at = datetime.now() + timedelta(hours=24)

        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                cursor.execute("""
                    INSERT OR REPLACE INTO auth_cookies
                    (provider, account_name, cookie_data, last_updated, expires_at, is_active)
                    VALUES (?, ?, ?, ?, ?, ?)
                """, (
                    provider_name, username, cookie_string,
                    datetime.now(), expires_at, True
                ))

                print(f"💾 认证信息已保存: {provider_name}@{username}")

        except sqlite3.Error as e:
            print(f"⚠️ 保存认证信息失败: {e}")

    def get_cached_session(self, provider_name: str, username: str) -> Optional[requests.Session]:
        """从数据库获取缓存的会话"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                cursor.execute("""
                    SELECT cookie_data, expires_at FROM auth_cookies
                    WHERE provider = ? AND account_name = ? AND is_active = 1
                    ORDER BY last_updated DESC LIMIT 1
                """, (provider_name, username))

                result = cursor.fetchone()
                if not result:
                    return None

                cookie_data, expires_at_str = result

                # 检查是否过期
                expires_at = datetime.fromisoformat(expires_at_str)
                if datetime.now() > expires_at:
                    print(f"🕐 缓存的 {provider_name} 会话已过期")
                    return None

                # 重建会话
                session = requests.Session()

                # 解析cookie字符串
                for cookie_pair in cookie_data.split('; '):
                    if '=' in cookie_pair:
                        key, value = cookie_pair.split('=', 1)
                        session.cookies.set(key, value)

                return session

        except (sqlite3.Error, ValueError) as e:
            print(f"⚠️ 获取缓存会话失败: {e}")
            return None

    def cleanup_expired_sessions(self):
        """清理过期的会话"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                cursor.execute("""
                    UPDATE auth_cookies
                    SET is_active = 0
                    WHERE expires_at < ? AND is_active = 1
                """, (datetime.now(),))

                cleaned_count = cursor.rowcount
                if cleaned_count > 0:
                    print(f"🧹 已清理 {cleaned_count} 个过期会话")

        except sqlite3.Error as e:
            print(f"⚠️ 清理过期会话失败: {e}")


# 便捷函数
def get_huawei_session(credentials: Optional[Dict[str, Any]] = None) -> requests.Session:
    """获取华为 W3 会话的便捷函数"""
    auth_manager = AuthManager()
    return auth_manager.authenticate('huawei_w3', credentials)


def main():
    """测试认证管理器"""
    try:
        auth_manager = AuthManager()

        # 清理过期会话
        auth_manager.cleanup_expired_sessions()

        # 尝试华为认证
        session = auth_manager.authenticate('huawei_w3')
        print(f"🎉 认证测试成功，获得 {len(session.cookies)} 个 cookies")

        # 测试会话缓存
        cached_session = auth_manager.authenticate('huawei_w3')
        print("🔄 会话缓存测试完成")

    except Exception as e:
        print(f"❌ 认证测试失败: {e}")


if __name__ == "__main__":
    main()