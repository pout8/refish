import requests
import urllib3
import sqlite3
from datetime import datetime

# 禁用SSL警告
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# --- 配置信息 ---
DB_FILE = "cookies.db"  # 指定数据库文件名
LOGIN_ACCOUNT = "h60099082"
PASSWORD ="xiao200112131115!"

# --- 登录逻辑 ---
session = requests.Session()
login_min = {
    "loginAccount": LOGIN_ACCOUNT,
    "password": PASSWORD,
    "uid": LOGIN_ACCOUNT,
    "targetUrl": "https%3A%2F%2Fw3.huawei.com%2Fnext%2Findexa.html",
}

session.headers.update({
    "Content-Type": "application/json;charset=UTF-8",
    "Referer": "https://w3.huawei.com/",
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36"
})

login_url = "https://login.huawei.com/login1/rest/hwidcenter/login"

try:
    print("正在尝试登录...")
    response = session.post(
        login_url,
        json=login_min,
        verify=False
    )
    response.raise_for_status()  # 如果请求失败 (例如 4xx 或 5xx 错误), 会抛出异常
    print("登录成功，Cookie已获取！")

    # --- 数据库操作 ---
    # 1. 将cookie字典拼接成一个字符串，方便存储
    cookie_string = "; ".join([f"{key}={value}" for key, value in session.cookies.items()])

    # 2. 准备要存入数据库的数据
    account = login_min["loginAccount"]
    current_time = datetime.now().strftime('%Y-%m-%d %H:%M:%S')

    # 3. 连接数据库并写入数据
    # 使用 "with" 语句可以确保数据库连接在使用后被安全关闭
    with sqlite3.connect(DB_FILE) as conn:
        cursor = conn.cursor()
        # 使用 INSERT OR REPLACE 来插入或更新记录
        # 使用占位符 (?) 来防止SQL注入，更安全
        sql_command = "INSERT OR REPLACE INTO cookies (account_name, cookie_data, last_updated) VALUES (?, ?, ?)"
        cursor.execute(sql_command, (account, cookie_string, current_time))
        # conn.commit() 会在 with 语句结束时自动调用

    print(f"账户 [{account}] 的Cookie已成功保存到数据库 [{DB_FILE}] 中。")

except requests.exceptions.RequestException as e:
    print(f"请求发生错误: {e}")
except sqlite3.Error as e:
    print(f"数据库操作失败: {e}")
