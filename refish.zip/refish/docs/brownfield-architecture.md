# Refish 硬件信息管理系统 - 棕地架构文档

## 项目介绍

本文档记录 **Refish** 项目的当前真实状态，包括技术债务、现有模式和实际架构。该文档专为 AI 代理和开发者提供准确的系统理解参考，支持基于 Redfish 标准的重构工作。

### 文档范围

**重构目标**: 将现有的非标准 BMC 硬件信息获取方式重构为基于 Redfish 标准的通用解决方案

### 变更日志

| 日期 | 版本 | 描述 | 作者 |
|------|------|------|------|
| 2025-10-02 | 1.0 | 初始棕地架构分析 | 浮浮酱(Winston) |

## 快速参考 - 关键文件和入口点

### 当前系统的关键文件

- **认证入口**: `loginCookies.py` - W3 SSO Cookie 获取
- **凭据获取**: `computing.py` - 平台凭据和 BMC 密码获取
- **硬件信息**: `bmc.py` - Redfish API 硬件信息获取 (已部分重构)
- **数据库**: `cookies.db` (SQLite) - Cookie 和认证信息存储
- **IP 列表**: `bmc_ip.txt` (缺失) - 目标服务器 IP 地址列表

### 重构影响区域

基于 Redfish 重构需求，以下文件将被影响：

- `bmc.py` - ✅ 已采用 Redfish 标准，需要增强普适性
- `computing.py` - 🔄 需要集成到统一数据库管理
- `loginCookies.py` - 🔄 需要统一到认证管理器
- 新增需要: 统一数据库管理、内存排序逻辑、主控制器

## 高层架构

### 技术概要

**当前状态**: 三个独立的 Python 脚本，通过 SQLite 数据库和文件系统进行松耦合

**目标状态**: 统一的 Redfish 硬件信息管理平台

### 实际技术栈

| 类别 | 技术 | 版本 | 说明 |
|------|------|------|------|
| 运行时 | Python | 3.x | 需要 asyncio 支持 |
| HTTP 客户端 | aiohttp | - | 仅在 bmc.py 中使用异步 |
| HTTP 客户端 | requests | - | loginCookies.py 和 computing.py 使用 |
| 数据库 | SQLite | 3.x | 本地文件数据库 `cookies.db` |
| SSL 处理 | urllib3 | - | 禁用 SSL 警告 |

### 仓库结构现状

- **类型**: 单仓库，简单脚本集合
- **包管理**: 无正式包管理文件
- **特点**: 无正式项目结构，脚本式开发

## 源码树和模块组织

### 项目结构 (实际)

```text
refish/
├── loginCookies.py          # W3 SSO 认证和 Cookie 获取
├── computing.py             # Kunpeng Lab 平台凭据获取
├── bmc.py                   # Redfish API 硬件信息获取 (现代化)
├── cookies.db               # SQLite 数据库 (运行时生成)
├── bmc_ip.txt               # IP 地址列表 (当前缺失)
├── .bmad-core/              # BMad 方法框架文件
├── .claude/                 # Claude 配置
└── .spec-workflow/          # 规范工作流配置
```

### 关键模块及其目的

#### 1. **认证层** (`loginCookies.py`)
- **目的**: 获取华为 W3 SSO 认证 Cookie
- **技术债务**: 硬编码账户信息，单一责任但缺乏配置管理
- **依赖**: requests, sqlite3
- **输出**: 更新 `cookies.db` 中的认证信息

#### 2. **凭据获取层** (`computing.py`)
- **目的**: 使用 Cookie 从 Kunpeng Lab 平台获取 BMC 凭据
- **架构模式**: 包含 `CookieManager` 类，相对现代化
- **技术债务**:
  - 硬编码的 `GROUP_ID` 和账户名
  - 混合同步/异步模式 (主要是同步)
  - 错误处理不够健壮
- **输出**: 控制台打印 IP、用户名、密码

#### 3. **硬件信息层** (`bmc.py`)
- **目的**: 通过 Redfish API 获取服务器硬件信息
- **技术优势**: ✅ 已采用现代异步架构
- **现有功能**:
  - 异步并发处理
  - 标准 Redfish API 支持
  - 分页处理
  - 多厂商兼容性
- **局限性**:
  - 依赖外部 `config.json` 文件
  - 内存信息无序排列
  - 缺乏与其他模块的集成

## 数据模型和 API

### 数据库模型

**当前 SQLite 结构** (`cookies.db`):

```sql
-- 现有表结构 (从 loginCookies.py 创建)
CREATE TABLE cookies (
    account_name TEXT PRIMARY KEY,
    cookie_data TEXT NOT NULL,
    last_updated TEXT
);
```

**缺失的数据模型**:
- 服务器凭据存储
- 硬件信息缓存
- 内存条详细信息

### API 接口

**华为 W3 SSO API**:
- 登录端点: `https://login.huawei.com/login1/rest/hwidcenter/login`
- 认证方式: JSON POST 请求

**Kunpeng Lab 平台 API**:
- 会话初始化: `https://kunpeng-lab.server.huawei.com/v1/system/user/login`
- 服务器搜索: `https://kunpeng-lab.server.huawei.com/v1/resource/server/get-server`
- 密码获取: `https://kunpeng-lab.server.huawei.com/v1/resource/server/get-password`

**Redfish API**:
- 标准端点: `/redfish/v1/Systems/1/`, `/redfish/v1/Systems/1/Memory/` 等
- 认证方式: Basic Auth

## 技术债务和已知问题

### 关键技术债务

1. **模块耦合度低但缺乏统一性**
   - 三个独立脚本，需要手动顺序执行
   - 没有统一的错误处理和重试机制
   - 配置信息分散在各个文件中

2. **安全问题**
   - `loginCookies.py` 中硬编码密码
   - SSL 验证被全局禁用
   - 数据库没有加密存储敏感信息

3. **数据管理不一致**
   - `computing.py` 输出到控制台，不持久化
   - `bmc.py` 需要外部配置文件
   - 缺乏统一的数据验证

4. **内存信息排序问题**
   - `bmc.py` 中的内存条信息按 API 返回顺序显示
   - 不支持槽位逻辑排序 (000, 010, 011 等)

### 工作区间和已知限制

- **Cookie 过期**: Cookie 需要定期刷新，无自动更新机制
- **网络依赖**: 所有脚本都依赖特定的华为内网服务
- **错误恢复**: 单点故障可能导致整个流程中断
- **IP 文件依赖**: `computing.py` 期望 `bmc_ip.txt` 存在

## 集成点和外部依赖

### 外部服务

| 服务 | 目的 | 集成类型 | 关键文件 |
|------|------|----------|----------|
| 华为 W3 SSO | 用户认证 | REST API | `loginCookies.py` |
| Kunpeng Lab | 资源管理 | REST API | `computing.py` |
| BMC Redfish | 硬件信息 | Redfish API | `bmc.py` |

### 内部集成点

- **数据库通信**: 通过 `cookies.db` SQLite 文件
- **文件系统**: 通过 `bmc_ip.txt` 传递 IP 列表
- **手动工作流**: 需要按顺序执行三个脚本

## 开发和部署

### 本地开发设置

**当前工作流程** (手动且繁琐):

1. 修改 `loginCookies.py` 中的账户信息
2. 运行 `python loginCookies.py` 获取 Cookie
3. 创建 `bmc_ip.txt` 文件并填入目标 IP
4. 运行 `python computing.py` 获取凭据
5. 根据输出创建 `config.json` 文件
6. 运行 `python bmc.py <ip>` 获取硬件信息

**已知设置问题**:
- 缺乏依赖管理文件 (`requirements.txt`)
- 敏感信息硬编码在源码中
- 无统一的配置管理

### 构建和部署过程

- **构建命令**: 无正式构建过程
- **部署**: 手动复制脚本文件
- **环境**: 仅支持开发环境

## 测试现状

### 当前测试覆盖率

- **单元测试**: 无
- **集成测试**: 无
- **端到端测试**: 无
- **手动测试**: 主要 QA 方法

### 运行测试

```bash
# 当前无自动化测试
# 只能手动验证各脚本功能
```

## 重构影响分析

### 需要修改的文件

基于 Redfish 重构需求，以下文件需要重大修改：

#### 高优先级修改
- `loginCookies.py` → `auth_manager.py` - 重构为通用认证管理器
- `computing.py` → `credential_fetcher.py` - 集成到统一数据库
- `bmc.py` - 增强内存排序功能，集成到统一系统

#### 需要新增的文件/模块
- `database_manager.py` - 统一数据库操作
- `memory_organizer.py` - 内存条智能排序
- `hardware_controller.py` - 主控制器和工作流编排
- `main.py` - 统一入口点
- `requirements.txt` - 依赖管理
- `config/settings.py` - 配置管理

### 集成考虑事项

- **向后兼容**: 保持现有数据库结构的兼容性
- **配置迁移**: 将硬编码配置迁移到配置文件
- **错误处理**: 建立统一的错误处理和重试机制
- **异步统一**: 将所有 HTTP 操作统一为异步模式

### 数据库迁移需求

```sql
-- 需要添加到现有 cookies.db
CREATE TABLE servers (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    bmc_ip TEXT UNIQUE NOT NULL,
    username TEXT NOT NULL,
    password TEXT NOT NULL,
    -- 其他字段...
);

CREATE TABLE memory_modules (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    server_id INTEGER NOT NULL,
    slot_id TEXT NOT NULL,
    slot_position INTEGER,
    -- 其他字段...
);
```

## 附录 - 有用的命令和脚本

### 当前使用的命令

```bash
# 获取认证 Cookie
python loginCookies.py

# 获取 BMC 凭据 (需要先创建 bmc_ip.txt)
python computing.py

# 获取硬件信息 (需要先创建 config.json)
python bmc.py <ip_address>

# 查看数据库内容
sqlite3 cookies.db "SELECT * FROM cookies;"
```

### 调试和故障排除

- **日志**: 当前输出到控制台，无持久化日志
- **调试模式**: 无统一的调试配置
- **常见问题**:
  - Cookie 过期需要重新登录
  - IP 文件格式错误导致脚本失败
  - 网络连接问题导致 API 调用失败

---

## 总结

**当前系统优势**:
- `bmc.py` 已采用现代 Redfish 标准
- SQLite 数据库提供基础数据持久化
- 异步处理提升性能

**主要改进机会**:
- 统一架构和工作流程
- 增强数据管理和安全性
- 实现内存条智能排序
- 建立完整的错误处理机制

该文档为 AI 代理提供了准确的系统现状理解，支持高效的 Redfish 重构工作。