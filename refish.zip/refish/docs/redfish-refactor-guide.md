# Redfish 重构实施指南

## 快速开始

这是浮浮酱为主人准备的 Redfish 重构实施指南，基于棕地架构分析提供具体的实施步骤。

## 🎯 重构目标回顾

将现有的三脚本系统重构为：
1. **统一的 Redfish 硬件信息管理平台**
2. **支持内存条按槽位排序 (000, 010, 011...)**
3. **集中的 SQLite 数据库管理**
4. **普适性的多厂商硬件支持**

## 📋 推荐实施顺序

### 阶段 1: 基础设施 (1-2 天)

#### 1.1 创建依赖管理
```bash
# 创建 requirements.txt
cat > requirements.txt << EOF
aiohttp>=3.8.0
requests>=2.28.0
urllib3>=1.26.0
asyncio
argparse
pathlib
EOF
```

#### 1.2 数据库迁移脚本
**优先级**: 🔥 **高** - 创建 `database_migration.py`

### 阶段 2: 核心重构 (2-3 天)

#### 2.1 认证管理器重构
**文件**: `loginCookies.py` → `auth_manager.py`
**重点**: 配置外部化，错误处理增强

#### 2.2 凭据获取器集成
**文件**: `computing.py` → `credential_fetcher.py`
**重点**: 与数据库管理器集成

#### 2.3 Redfish 客户端增强
**文件**: `bmc.py` → `redfish_client.py`
**重点**: 添加内存排序功能

### 阶段 3: 新增模块 (1-2 天)

#### 3.1 内存排序器
**新文件**: `memory_organizer.py`
**核心功能**: 智能槽位识别和排序

#### 3.2 数据库管理器
**新文件**: `database_manager.py`
**核心功能**: 统一数据操作接口

#### 3.3 主控制器
**新文件**: `hardware_controller.py`
**核心功能**: 工作流编排

### 阶段 4: 集成 (1 天)

#### 4.1 统一入口
**新文件**: `main.py`
**功能**: 命令行界面和流程控制

## 🔧 关键实施细节

### 内存排序实现重点

```python
# 关键排序逻辑 (在 memory_organizer.py 中)
def parse_slot_id(slot_name: str) -> tuple[int, str]:
    """华为服务器槽位解析: 000 → 0, 010 → 10, 011 → 11"""
    if re.match(r'^\d{3}$', slot_name):
        return (int(slot_name), slot_name)
    # 其他厂商逻辑...
```

### 数据库扩展

```sql
-- 核心新增表 (在 database_migration.py 中)
CREATE TABLE servers (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    bmc_ip TEXT UNIQUE NOT NULL,
    username TEXT NOT NULL,
    password TEXT NOT NULL,
    status TEXT DEFAULT 'unknown'
);

CREATE TABLE memory_modules (
    server_id INTEGER NOT NULL,
    slot_id TEXT NOT NULL,
    slot_position INTEGER,  -- 用于排序
    capacity_gb INTEGER,
    UNIQUE(server_id, slot_id)
);
```

### 配置管理

```python
# config/settings.py
HUAWEI_LOGIN_URL = "https://login.huawei.com/login1/rest/hwidcenter/login"
KUNPENG_LAB_BASE_URL = "https://kunpeng-lab.server.huawei.com"
DATABASE_PATH = "refish_hardware.db"  # 新数据库名
```

## 🚀 立即开始的建议

浮浮酱建议主人从以下步骤开始：

1. **创建 `requirements.txt`** - 明确依赖关系
2. **实施数据库迁移** - 扩展现有 SQLite 结构
3. **重构内存排序逻辑** - 解决核心业务需求
4. **集成现有 Redfish 客户端** - 利用已有的优秀代码

### 第一个实施脚本建议

```bash
# 创建项目结构
mkdir -p config src tests docs
mv *.py src/  # 移动现有文件到 src
# 然后开始重构...
```

## 📊 成功标准

重构完成后应该实现：
- ✅ 单一命令执行完整流程
- ✅ 内存条按 000→010→011 顺序显示
- ✅ 所有 IP、凭据存储在数据库中
- ✅ 支持多厂商 Redfish 标准
- ✅ 统一的错误处理和重试机制

---

**下一步**: 告诉浮浮酱您想要从哪个阶段开始实施，浮浮酱会提供详细的代码指导！ ฅ'ω'ฅ