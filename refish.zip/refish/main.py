#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Refish 硬件信息管理系统 - 主入口
浮浮酱精心制作的统一 Redfish 硬件管理平台 ฅ'ω'ฅ

特性:
- 统一的命令行界面
- 支持多种输出格式 (table, json, detailed)
- 集成认证、凭据获取和硬件信息收集
- 内存按槽位智能排序
- 多厂商 Redfish 标准支持
- 配置文件和环境变量支持
"""

import sys
import asyncio
import argparse
from pathlib import Path
from typing import List, Optional
import json

# 添加src目录到Python路径
src_path = Path(__file__).parent / "src"
sys.path.insert(0, str(src_path))

try:
    from redfish_client import RedfishManager, HardwareType
    from credential_fetcher import CredentialFetcher
    from auth_manager import AuthManager
    from config.settings import RefishConfig
except ImportError as e:
    print(f"❌ 模块导入失败: {e}")
    print("请确保所有依赖模块都在 src/ 目录中")
    sys.exit(1)


class RedfishCLI:
    """Refish 命令行界面"""

    def __init__(self):
        self.config = RefishConfig()
        self.manager = RedfishManager()

    def create_parser(self) -> argparse.ArgumentParser:
        """创建命令行参数解析器"""
        parser = argparse.ArgumentParser(
            description="Refish 硬件信息管理系统 - 浮浮酱制作 ฅ'ω'ฅ",
            formatter_class=argparse.RawDescriptionHelpFormatter,
            epilog="""
示例用法:
  # 从文件读取IP并收集所有硬件信息
  python main.py --input bmc_ip.txt --output detailed

  # 指定IP地址收集内存信息
  python main.py --ip 192.168.1.100,192.168.1.101 --hardware memory

  # 输出JSON格式
  python main.py --input bmc_ip.txt --format json --save result.json

  # 仅获取凭据不收集硬件信息
  python main.py --input bmc_ip.txt --credentials-only

环境变量:
  HUAWEI_LOGIN_ACCOUNT  华为登录账号
  HUAWEI_PASSWORD       华为登录密码
  REFISH_DB_PATH        数据库文件路径
            """)

        # 输入选项
        input_group = parser.add_mutually_exclusive_group(required=True)
        input_group.add_argument(
            '--input', '-i',
            type=str,
            help='包含IP地址的文件路径 (每行一个IP)'
        )
        input_group.add_argument(
            '--ip',
            type=str,
            help='IP地址，多个IP用逗号分隔'
        )

        # 功能选项
        parser.add_argument(
            '--hardware', '-H',
            choices=['system', 'cpu', 'memory', 'storage', 'pcie', 'all'],
            default='all',
            help='要收集的硬件类型 (默认: all)'
        )

        parser.add_argument(
            '--format', '-f',
            choices=['table', 'detailed', 'json'],
            default='table',
            help='输出格式 (默认: table)'
        )

        parser.add_argument(
            '--save', '-s',
            type=str,
            help='保存结果到文件'
        )

        parser.add_argument(
            '--credentials-only', '-c',
            action='store_true',
            help='仅获取凭据，不收集硬件信息'
        )

        # 配置选项
        parser.add_argument(
            '--provider',
            default='kunpeng_lab',
            help='凭据提供器 (默认: kunpeng_lab)'
        )

        parser.add_argument(
            '--timeout',
            type=int,
            default=30,
            help='请求超时时间（秒，默认: 30）'
        )

        parser.add_argument(
            '--concurrent',
            type=int,
            default=10,
            help='最大并发数 (默认: 10)'
        )

        # 调试选项
        parser.add_argument(
            '--verbose', '-v',
            action='store_true',
            help='详细输出'
        )

        parser.add_argument(
            '--version',
            action='version',
            version='Refish 2.0.0 - 浮浮酱制作'
        )

        return parser

    def parse_ip_list(self, args: argparse.Namespace) -> List[str]:
        """解析IP地址列表"""
        if args.input:
            return self._read_ips_from_file(args.input)
        elif args.ip:
            return [ip.strip() for ip in args.ip.split(',') if ip.strip()]
        return []

    def _read_ips_from_file(self, file_path: str) -> List[str]:
        """从文件读取IP地址"""
        try:
            path = Path(file_path)
            if not path.exists():
                print(f"❌ 文件不存在: {file_path}")
                return []

            lines = path.read_text(encoding='utf-8').splitlines()
            ip_list = [line.strip() for line in lines if line.strip() and not line.startswith('#')]

            if not ip_list:
                print(f"⚠️ 文件 {file_path} 中没有找到有效的IP地址")

            return ip_list

        except Exception as e:
            print(f"❌ 读取IP文件失败: {e}")
            return []

    async def run_credentials_only(self, ip_list: List[str], provider: str) -> bool:
        """仅获取凭据"""
        print(f"🔑 获取 {len(ip_list)} 个IP的凭据...")

        credential_fetcher = CredentialFetcher()
        credentials = credential_fetcher.fetch_credentials(ip_list, provider)

        if credentials:
            print(f"\n✅ 成功获取 {len(credentials)} 个服务器的凭据:")
            for cred in credentials:
                print(f"   - {cred.ip}: {cred.username} (过期时间: {cred.expires_at})")
            return True
        else:
            print("❌ 未获取到任何凭据")
            return False

    async def run_hardware_collection(self, ip_list: List[str], hardware_type: str,
                                      output_format: str, save_file: Optional[str] = None) -> bool:
        """收集硬件信息"""
        print(f"📡 收集 {len(ip_list)} 个服务器的 {hardware_type} 硬件信息...")

        # 转换硬件类型
        hw_types = [HardwareType.ALL] if hardware_type == 'all' else [HardwareType(hardware_type)]

        # 收集硬件信息
        hardware_info = await self.manager.collect_hardware_info(ip_list, hw_types)

        if not hardware_info:
            print("❌ 未收集到任何硬件信息")
            return False

        # 输出结果
        if save_file:
            self._save_results(hardware_info, save_file, output_format)
        else:
            self.manager.print_hardware_info(hardware_info, output_format)

        return True

    def _save_results(self, hardware_info: dict, file_path: str, format_type: str):
        """保存结果到文件"""
        try:
            path = Path(file_path)
            path.parent.mkdir(parents=True, exist_ok=True)

            if format_type == 'json':
                json_data = {ip: info.to_dict() for ip, info in hardware_info.items()}
                path.write_text(json.dumps(json_data, indent=2, ensure_ascii=False), encoding='utf-8')
            else:
                # 重定向输出到文件
                import io
                from contextlib import redirect_stdout

                output = io.StringIO()
                with redirect_stdout(output):
                    self.manager.print_hardware_info(hardware_info, format_type)

                path.write_text(output.getvalue(), encoding='utf-8')

            print(f"💾 结果已保存到: {file_path}")

        except Exception as e:
            print(f"❌ 保存文件失败: {e}")

    def check_environment(self) -> bool:
        """检查运行环境"""
        print("🔍 检查运行环境...")

        # 验证配置
        validation_result = self.config.validate_config()

        if validation_result["errors"]:
            print("❌ 配置错误:")
            for error in validation_result["errors"]:
                print(f"   - {error}")
            return False

        if validation_result["warnings"]:
            print("⚠️ 配置警告:")
            for warning in validation_result["warnings"]:
                print(f"   - {warning}")

        print("✅ 环境检查完成")
        return True

    async def run(self, args: argparse.Namespace) -> int:
        """运行主程序"""
        # 检查环境
        if not self.check_environment():
            return 1

        # 解析IP列表
        ip_list = self.parse_ip_list(args)
        if not ip_list:
            print("❌ 未找到有效的IP地址")
            return 1

        print(f"📋 待处理IP地址: {len(ip_list)} 个")
        if args.verbose:
            for ip in ip_list:
                print(f"   - {ip}")

        try:
            if args.credentials_only:
                success = await self.run_credentials_only(ip_list, args.provider)
            else:
                success = await self.run_hardware_collection(
                    ip_list, args.hardware, args.format, args.save
                )

            return 0 if success else 1

        except KeyboardInterrupt:
            print("\n⚠️ 用户中断操作")
            return 130
        except Exception as e:
            print(f"❌ 执行失败: {e}")
            if args.verbose:
                import traceback
                traceback.print_exc()
            return 1


def show_banner():
    """显示欢迎横幅"""
    banner = """
    ╭─────────────────────────────────────────────────────────────╮
    │                                                             │
    │     🖥️  REFISH 硬件信息管理系统 v2.0.0                    │
    │                                                             │
    │         基于 Redfish 标准的统一硬件管理平台                │
    │                 浮浮酱精心制作 ฅ'ω'ฅ                      │
    │                                                             │
    ╰─────────────────────────────────────────────────────────────╯
    """
    print(banner)


async def main():
    """主函数"""
    show_banner()

    cli = RedfishCLI()
    parser = cli.create_parser()
    args = parser.parse_args()

    return await cli.run(args)


if __name__ == "__main__":
    try:
        exit_code = asyncio.run(main())
        sys.exit(exit_code)
    except Exception as e:
        print(f"❌ 程序启动失败: {e}")
        sys.exit(1)