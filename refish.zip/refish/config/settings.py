#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Refish 配置管理系统
浮浮酱的统一配置管理方案 ฅ'ω'ฅ

功能:
- 集中管理所有系统配置
- 环境变量支持
- 配置验证和默认值
- 敏感信息保护
"""

import os
from pathlib import Path
from typing import Optional, Dict, Any
import json


class RefishConfig:
    """Refish 系统配置管理器"""

    def __init__(self, config_file: Optional[str] = None):
        """
        初始化配置管理器

        Args:
            config_file: 可选的配置文件路径
        """
        self.config_file = config_file or "config/refish.json"
        self.config_data = {}
        self._load_config()

    def _load_config(self):
        """加载配置文件"""
        config_path = Path(self.config_file)
        if config_path.exists():
            try:
                with open(config_path, 'r', encoding='utf-8') as f:
                    self.config_data = json.load(f)
            except Exception as e:
                print(f"⚠️  配置文件加载失败: {e}")

    # === 数据库配置 ===
    @property
    def database_path(self) -> str:
        """数据库文件路径"""
        return self.get("database.path", "refish_hardware.db")

    @property
    def legacy_database_path(self) -> str:
        """旧数据库文件路径"""
        return self.get("database.legacy_path", "cookies.db")

    @property
    def database_backup_enabled(self) -> bool:
        """是否启用数据库备份"""
        return self.get("database.backup_enabled", True)

    # === 华为 W3 SSO 配置 ===
    @property
    def huawei_login_url(self) -> str:
        """华为登录 URL"""
        return self.get("auth.huawei.login_url",
                       "https://login.huawei.com/login1/rest/hwidcenter/login")

    @property
    def huawei_login_account(self) -> str:
        """华为登录账号"""
        # 优先从环境变量获取
        account = os.getenv("HUAWEI_LOGIN_ACCOUNT")
        if account:
            return account
        return self.get("auth.huawei.login_account", "")

    @property
    def huawei_password(self) -> str:
        """华为登录密码"""
        # 优先从环境变量获取
        password = os.getenv("HUAWEI_PASSWORD")
        if password:
            return password
        return self.get("auth.huawei.password", "")

    # === Kunpeng Lab 配置 ===
    @property
    def kunpeng_base_url(self) -> str:
        """Kunpeng Lab 基础 URL"""
        return self.get("kunpeng.base_url",
                       "https://kunpeng-lab.server.huawei.com")

    @property
    def kunpeng_group_id(self) -> str:
        """Kunpeng Lab 资源组 ID"""
        return self.get("kunpeng.group_id",
                       "paddde0df492d4f9487ac491ad2f4c501")

    @property
    def kunpeng_login_endpoint(self) -> str:
        """Kunpeng Lab 登录端点"""
        return f"{self.kunpeng_base_url}/v1/system/user/login"

    @property
    def kunpeng_server_search_endpoint(self) -> str:
        """Kunpeng Lab 服务器搜索端点"""
        return f"{self.kunpeng_base_url}/v1/resource/server/get-server"

    @property
    def kunpeng_password_endpoint(self) -> str:
        """Kunpeng Lab 密码获取端点"""
        return f"{self.kunpeng_base_url}/v1/resource/server/get-password"

    # === Redfish 配置 ===
    @property
    def redfish_timeout(self) -> int:
        """Redfish API 超时时间 (秒)"""
        return self.get("redfish.timeout", 30)

    @property
    def redfish_verify_ssl(self) -> bool:
        """是否验证 SSL 证书"""
        return self.get("redfish.verify_ssl", False)

    @property
    def redfish_max_concurrent(self) -> int:
        """最大并发连接数"""
        return self.get("redfish.max_concurrent", 10)

    # === HTTP 配置 ===
    @property
    def http_user_agent(self) -> str:
        """HTTP User-Agent"""
        return self.get("http.user_agent",
                       "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36")

    @property
    def http_timeout(self) -> int:
        """HTTP 请求超时时间 (秒)"""
        return self.get("http.timeout", 15)

    # === 缓存配置 ===
    @property
    def cache_ttl_hours(self) -> int:
        """缓存有效期 (小时)"""
        return self.get("cache.ttl_hours", 24)

    @property
    def cache_enabled(self) -> bool:
        """是否启用缓存"""
        return self.get("cache.enabled", True)

    # === 日志配置 ===
    @property
    def log_level(self) -> str:
        """日志级别"""
        return self.get("logging.level", "INFO")

    @property
    def log_file_path(self) -> str:
        """日志文件路径"""
        return self.get("logging.file_path", "logs/refish.log")

    @property
    def log_max_size_mb(self) -> int:
        """日志文件最大大小 (MB)"""
        return self.get("logging.max_size_mb", 10)

    # === 内存排序配置 ===
    @property
    def memory_sort_pattern(self) -> str:
        """默认内存排序模式"""
        return self.get("memory.sort_pattern", "huawei")

    @property
    def memory_show_empty_slots(self) -> bool:
        """是否显示空槽位"""
        return self.get("memory.show_empty_slots", True)

    # === 工具方法 ===
    def get(self, key: str, default: Any = None) -> Any:
        """
        获取配置值，支持点号分隔的嵌套键

        Args:
            key: 配置键，如 "database.path"
            default: 默认值

        Returns:
            配置值或默认值
        """
        keys = key.split('.')
        value = self.config_data

        for k in keys:
            if isinstance(value, dict) and k in value:
                value = value[k]
            else:
                return default

        return value

    def set(self, key: str, value: Any):
        """
        设置配置值

        Args:
            key: 配置键
            value: 配置值
        """
        keys = key.split('.')
        target = self.config_data

        for k in keys[:-1]:
            if k not in target:
                target[k] = {}
            target = target[k]

        target[keys[-1]] = value

    def save_config(self):
        """保存配置到文件"""
        config_path = Path(self.config_file)
        config_path.parent.mkdir(parents=True, exist_ok=True)

        try:
            with open(config_path, 'w', encoding='utf-8') as f:
                json.dump(self.config_data, f, indent=2, ensure_ascii=False)
        except Exception as e:
            print(f"❌ 保存配置文件失败: {e}")

    def validate_config(self) -> Dict[str, list]:
        """
        验证配置完整性

        Returns:
            验证结果字典: {"errors": [], "warnings": []}
        """
        result = {"errors": [], "warnings": []}

        # 检查必需的配置
        if not self.huawei_login_account:
            result["errors"].append("缺少华为登录账号配置")

        if not self.huawei_password:
            result["warnings"].append("缺少华为登录密码，请设置环境变量 HUAWEI_PASSWORD")

        # 检查数据库路径
        if not Path(self.database_path).parent.exists():
            result["warnings"].append(f"数据库目录不存在: {Path(self.database_path).parent}")

        return result

    def create_sample_config(self):
        """创建示例配置文件"""
        sample_config = {
            "database": {
                "path": "refish_hardware.db",
                "legacy_path": "cookies.db",
                "backup_enabled": True
            },
            "auth": {
                "huawei": {
                    "login_url": "https://login.huawei.com/login1/rest/hwidcenter/login",
                    "login_account": "请设置您的账号",
                    "password": "请使用环境变量 HUAWEI_PASSWORD"
                }
            },
            "kunpeng": {
                "base_url": "https://kunpeng-lab.server.huawei.com",
                "group_id": "paddde0df492d4f9487ac491ad2f4c501"
            },
            "redfish": {
                "timeout": 30,
                "verify_ssl": False,
                "max_concurrent": 10
            },
            "http": {
                "user_agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
                "timeout": 15
            },
            "cache": {
                "ttl_hours": 24,
                "enabled": True
            },
            "logging": {
                "level": "INFO",
                "file_path": "logs/refish.log",
                "max_size_mb": 10
            },
            "memory": {
                "sort_pattern": "huawei",
                "show_empty_slots": True
            }
        }

        self.config_data = sample_config
        self.save_config()
        print(f"✅ 示例配置文件已创建: {self.config_file}")


# 全局配置实例
config = RefishConfig()


def get_config() -> RefishConfig:
    """获取全局配置实例"""
    return config


def create_sample_config():
    """创建示例配置文件的便捷函数"""
    config.create_sample_config()


if __name__ == "__main__":
    # 创建示例配置文件
    create_sample_config()

    # 验证配置
    validation_result = config.validate_config()
    if validation_result["errors"]:
        print("❌ 配置错误:")
        for error in validation_result["errors"]:
            print(f"   - {error}")

    if validation_result["warnings"]:
        print("⚠️  配置警告:")
        for warning in validation_result["warnings"]:
            print(f"   - {warning}")

    print("\n📋 当前配置概览:")
    print(f"   - 数据库路径: {config.database_path}")
    print(f"   - 华为账号: {config.huawei_login_account}")
    print(f"   - Kunpeng URL: {config.kunpeng_base_url}")
    print(f"   - Redfish 超时: {config.redfish_timeout}s")